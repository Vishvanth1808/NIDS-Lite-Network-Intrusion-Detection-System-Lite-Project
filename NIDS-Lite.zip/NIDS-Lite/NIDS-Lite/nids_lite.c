#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <time.h>

#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/if_ether.h>
#include <net/ethernet.h>
#include <netpacket/packet.h>

/* simple ANSI color helpers */
#define _CSI "\x1b["
#define COLOR_RESET   _CSI "0m"
#define COLOR_RED     _CSI "31m"
#define COLOR_GREEN   _CSI "32m"
#define COLOR_YELLOW  _CSI "33m"
#define COLOR_BLUE    _CSI "34m"
#define COLOR_MAGENTA _CSI "35m"
#define COLOR_CYAN    _CSI "36m"

/* runtime flags / counters */
static volatile int keep_running = 1;
static unsigned long total_packets = 0;
static unsigned long ip_packets    = 0;
static unsigned long tcp_packets   = 0;
static unsigned long udp_packets   = 0;
static unsigned long arp_packets   = 0;
static unsigned long dns_packets   = 0;
static unsigned long syn_packets   = 0;
static unsigned long alerts_raised = 0;

/* detection parameters */
#define MAX_TRACKED_IPS        256
#define MAX_PORTS_PER_IP       128
#define SYN_WINDOW_SECONDS     5
#define SYN_FLOOD_THRESHOLD    100

#define SCAN_WINDOW_SECONDS    10
#define SCAN_PORT_THRESHOLD    20
#define ARP_TABLE_SIZE         256

#define DNS_LONG_DOMAIN_LEN    50
#define DNS_TRACKED_IPS        128
#define DNS_WINDOW_SECONDS     10
#define DNS_QUERY_THRESHOLD    30

/* signal */
static void handle_sigint(int sig) {
    (void)sig;
    keep_running = 0;
}

/* address helpers */
static void ip_to_str(uint32_t ip, char *buf, size_t len) {
    struct in_addr addr;
    addr.s_addr = ip;
    if (!inet_ntop(AF_INET, &addr, buf, (socklen_t)len)) {
        snprintf(buf, len, "?.?.?.?");
    }
}

static void mac_to_str(const unsigned char *mac, char *buf, size_t len) {
    snprintf(buf, len, "%02x:%02x:%02x:%02x:%02x:%02x",
             mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
}

/* SYN flood detector */
typedef struct {
    uint32_t ip;
    time_t   first_ts;
    int      syn_count;
    int      in_use;
} syn_entry_t;

static syn_entry_t syn_table[MAX_TRACKED_IPS];

static void reset_syn_entry(syn_entry_t *e) {
    e->ip = 0;
    e->first_ts = 0;
    e->syn_count = 0;
    e->in_use = 0;
}

static void init_syn_table(void) {
    int i = 0;
    while (i < MAX_TRACKED_IPS) {
        reset_syn_entry(&syn_table[i]);
        i++;
    }
}

/* if threshold reached, we reduce count instead of fully zeroing to avoid spamming */
static void detect_syn_flood(uint32_t src_ip) {
    time_t now = time(NULL);
    int free_idx = -1;
    int i = 0;

    while (i < MAX_TRACKED_IPS) {
        syn_entry_t *e = &syn_table[i];
        if (e->in_use && e->ip == src_ip) {
            if ((now - e->first_ts) > SYN_WINDOW_SECONDS) {
                e->first_ts = now;
                e->syn_count = 1;
            } else {
                e->syn_count++;
                if (e->syn_count >= SYN_FLOOD_THRESHOLD) {
                    char ipbuf[64];
                    ip_to_str(src_ip, ipbuf, sizeof(ipbuf));
                    printf(COLOR_RED "[ALERT] Possible SYN flood: src=%s SYN_count=%d (window=%ds)\n" COLOR_RESET,
                           ipbuf, e->syn_count, SYN_WINDOW_SECONDS);
                    alerts_raised++;
                    /* reduce count to half threshold to add a passive cooldown */
                    e->syn_count = SYN_FLOOD_THRESHOLD / 2;
                    e->first_ts = now;
                }
            }
            return;
        }
        if (!e->in_use && free_idx == -1) {
            free_idx = i;
        }
        i++;
    }

    if (free_idx != -1) {
        syn_entry_t *e = &syn_table[free_idx];
        e->ip = src_ip;
        e->first_ts = now;
        e->syn_count = 1;
        e->in_use = 1;
    }
}

/* port scan detector */
typedef struct {
    uint32_t ip;
    time_t   first_ts;
    uint16_t ports[MAX_PORTS_PER_IP];
    int      port_count;
    int      in_use;
} scan_entry_t;

static scan_entry_t scan_table[MAX_TRACKED_IPS];

static void reset_scan_entry(scan_entry_t *e) {
    e->ip = 0;
    e->first_ts = 0;
    e->port_count = 0;
    e->in_use = 0;
    memset(e->ports, 0, sizeof(e->ports));
}

static void init_scan_table(void) {
    int i = 0;
    while (i < MAX_TRACKED_IPS) {
        reset_scan_entry(&scan_table[i]);
        i++;
    }
}

/* linear search for a port */
static int has_port(scan_entry_t *e, uint16_t port) {
    int idx = 0;
    while (idx < e->port_count) {
        if (e->ports[idx] == port) return 1;
        idx++;
    }
    return 0;
}

/* detect distinct ports per src IP; when threshold reached reduce list size */
static void detect_port_scan(uint32_t src_ip, uint16_t dst_port) {
    time_t now = time(NULL);
    int free_idx = -1;
    int i = 0;

    while (i < MAX_TRACKED_IPS) {
        scan_entry_t *e = &scan_table[i];
        if (e->in_use && e->ip == src_ip) {
            if ((now - e->first_ts) > SCAN_WINDOW_SECONDS) {
                e->first_ts = now;
                e->port_count = 0;
                memset(e->ports, 0, sizeof(e->ports));
            }
            if (!has_port(e, dst_port)) {
                if (e->port_count < MAX_PORTS_PER_IP) {
                    e->ports[e->port_count++] = dst_port;
                }
            }
            if (e->port_count >= SCAN_PORT_THRESHOLD) {
                char ipbuf[64];
                ip_to_str(src_ip, ipbuf, sizeof(ipbuf));
                printf(COLOR_MAGENTA "[ALERT] Possible port scan: src=%s distinct_ports=%d (window=%ds)\n"
                       COLOR_RESET, ipbuf, e->port_count, SCAN_WINDOW_SECONDS);
                alerts_raised++;
                /* keep half of ports so detection can resume without immediate re-alert */
                int keep = e->port_count / 2;
                if (keep < 0) keep = 0;
                for (int j = 0; j < keep; ++j) {
                    e->ports[j] = e->ports[j]; /* preserve first half */
                }
                e->port_count = keep;
                e->first_ts = now;
            }
            return;
        }
        if (!e->in_use && free_idx == -1) {
            free_idx = i;
        }
        i++;
    }

    if (free_idx != -1) {
        scan_entry_t *e = &scan_table[free_idx];
        e->ip = src_ip;
        e->first_ts = now;
        e->in_use = 1;
        e->port_count = 0;
        memset(e->ports, 0, sizeof(e->ports));
        e->ports[e->port_count++] = dst_port;
    }
}

/* ARP spoof detector */
typedef struct {
    uint32_t ip;
    unsigned char mac[6];
    int in_use;
} arp_entry_t;

static arp_entry_t arp_table[ARP_TABLE_SIZE];

static void reset_arp_entry(arp_entry_t *e) {
    e->ip = 0;
    memset(e->mac, 0, 6);
    e->in_use = 0;
}

static void init_arp_table(void) {
    int i = 0;
    while (i < ARP_TABLE_SIZE) {
        reset_arp_entry(&arp_table[i]);
        i++;
    }
}

static int mac_equal(const unsigned char *m1, const unsigned char *m2) {
    return memcmp(m1, m2, 6) == 0;
}

static void detect_arp_spoof(uint32_t ip, const unsigned char *mac) {
    int free_idx = -1;
    int i = 0;

    while (i < ARP_TABLE_SIZE) {
        arp_entry_t *e = &arp_table[i];
        if (e->in_use && e->ip == ip) {
            if (!mac_equal(e->mac, mac)) {
                char ipbuf[64], old_mac[32], new_mac[32];
                ip_to_str(ip, ipbuf, sizeof(ipbuf));
                mac_to_str(e->mac, old_mac, sizeof(old_mac));
                mac_to_str(mac, new_mac, sizeof(new_mac));
                printf(COLOR_RED "[ALERT] Possible ARP spoof: IP=%s oldMAC=%s newMAC=%s\n" COLOR_RESET,
                       ipbuf, old_mac, new_mac);
                alerts_raised++;
                memcpy(e->mac, mac, 6);
            }
            return;
        }
        if (!e->in_use && free_idx == -1) {
            free_idx = i;
        }
        i++;
    }

    if (free_idx != -1) {
        arp_entry_t *e = &arp_table[free_idx];
        e->ip = ip;
        memcpy(e->mac, mac, 6);
        e->in_use = 1;
    }
}

/* DNS tunneling heuristic */
typedef struct {
    uint32_t ip;
    time_t   first_ts;
    int      query_count;
    int      in_use;
} dns_entry_t;

static dns_entry_t dns_table[DNS_TRACKED_IPS];

static void reset_dns_entry(dns_entry_t *e) {
    e->ip = 0;
    e->first_ts = 0;
    e->query_count = 0;
    e->in_use = 0;
}

static void init_dns_table(void) {
    int i = 0;
    while (i < DNS_TRACKED_IPS) {
        reset_dns_entry(&dns_table[i]);
        i++;
    }
}

static void detect_dns_rate(uint32_t src_ip) {
    time_t now = time(NULL);
    int free_idx = -1;
    int i = 0;

    while (i < DNS_TRACKED_IPS) {
        dns_entry_t *e = &dns_table[i];
        if (e->in_use && e->ip == src_ip) {
            if ((now - e->first_ts) > DNS_WINDOW_SECONDS) {
                e->first_ts = now;
                e->query_count = 0;
            }
            e->query_count++;
            if (e->query_count >= DNS_QUERY_THRESHOLD) {
                char ipbuf[64];
                ip_to_str(src_ip, ipbuf, sizeof(ipbuf));
                printf(COLOR_YELLOW "[ALERT] Suspicious DNS activity: src=%s queries=%d (window=%ds)\n"
                       COLOR_RESET, ipbuf, e->query_count, DNS_WINDOW_SECONDS);
                alerts_raised++;
                /* decay count so it doesn't spam */
                e->query_count = DNS_QUERY_THRESHOLD / 2;
                e->first_ts = now;
            }
            return;
        }
        if (!e->in_use && free_idx == -1) {
            free_idx = i;
        }
        i++;
    }

    if (free_idx != -1) {
        dns_entry_t *e = &dns_table[free_idx];
        e->ip = src_ip;
        e->first_ts = now;
        e->query_count = 1;
        e->in_use = 1;
    }
}

/* parse DNS qname length: replaced loop structure */
static int parse_dns_qname_len(const unsigned char *payload,
                               size_t len,
                               size_t offset)
{
    int total = 0;
    for (size_t pos = offset; pos < len; ) {
        unsigned char label_len = payload[pos];
        if (label_len == 0) break;
        pos++;
        if (pos + label_len > len) break;
        total += label_len;
        if (total > 0) total++;
        pos += label_len;
    }
    return total;
}

/* packet handlers */
static void handle_arp(const unsigned char *buffer, size_t size) {
    if (size < sizeof(struct ethhdr) + sizeof(struct ether_arp)) return;
    const struct ether_arp *arp = (const struct ether_arp *)(buffer + sizeof(struct ethhdr));
    arp_packets++;
    if (ntohs(arp->ea_hdr.ar_op) != ARPOP_REPLY && ntohs(arp->ea_hdr.ar_op) != ARPOP_REQUEST) return;
    uint32_t sip;
    memcpy(&sip, arp->arp_spa, sizeof(uint32_t));
    const unsigned char *sha = arp->arp_sha;
    detect_arp_spoof(sip, sha);
}

static void handle_dns(const unsigned char *payload,
                       size_t len,
                       uint32_t src_ip,
                       uint32_t dst_ip)
{
    (void)dst_ip;
    if (len < 12) return;
    dns_packets++;
    uint16_t id      = (payload[0] << 8) | payload[1];
    uint16_t flags   = (payload[2] << 8) | payload[3];
    uint16_t qdcount = (payload[4] << 8) | payload[5];
    (void)id;
    int qr = (flags & 0x8000) ? 1 : 0;
    if (!qr && qdcount > 0) {
        detect_dns_rate(src_ip);
        int qname_len = parse_dns_qname_len(payload, len, 12);
        if (qname_len > DNS_LONG_DOMAIN_LEN) {
            char ipbuf[64];
            ip_to_str(src_ip, ipbuf, sizeof(ipbuf));
            printf(COLOR_CYAN "[ALERT] Suspicious long DNS query: src=%s qname_len=%d\n" COLOR_RESET,
                   ipbuf, qname_len);
            alerts_raised++;
        }
    }
}

static void handle_udp(const unsigned char *buffer, size_t size) {
    if (size < sizeof(struct ethhdr) + sizeof(struct iphdr) + sizeof(struct udphdr)) return;
    const struct iphdr *iph = (const struct iphdr *)(buffer + sizeof(struct ethhdr));
    unsigned int iphdr_len = iph->ihl * 4;
    if (size < sizeof(struct ethhdr) + iphdr_len + sizeof(struct udphdr)) return;
    const struct udphdr *udph = (const struct udphdr *)(buffer + sizeof(struct ethhdr) + iphdr_len);
    udp_packets++;
    uint16_t src_port = ntohs(udph->source);
    uint16_t dst_port = ntohs(udph->dest);
    if (src_port == 53 || dst_port == 53) {
        size_t udp_header_offset = sizeof(struct ethhdr) + iphdr_len;
        size_t udp_payload_offset = udp_header_offset + sizeof(struct udphdr);
        if (size > udp_payload_offset) {
            const unsigned char *dns_payload = buffer + udp_payload_offset;
            size_t dns_len = size - udp_payload_offset;
            handle_dns(dns_payload, dns_len, iph->saddr, iph->daddr);
        }
    }
}

static void handle_tcp(const unsigned char *buffer, size_t size) {
    if (size < sizeof(struct ethhdr) + sizeof(struct iphdr) + sizeof(struct tcphdr)) return;
    const struct iphdr *iph = (const struct iphdr *)(buffer + sizeof(struct ethhdr));
    unsigned int iphdr_len = iph->ihl * 4;
    if (size < sizeof(struct ethhdr) + iphdr_len + sizeof(struct tcphdr)) return;
    const struct tcphdr *tcph = (const struct tcphdr *)(buffer + sizeof(struct ethhdr) + iphdr_len);
    tcp_packets++;
    uint32_t src_ip = iph->saddr;
    uint32_t dst_ip = iph->daddr;
    uint16_t src_port = ntohs(tcph->source);
    uint16_t dst_port = ntohs(tcph->dest);
    if (tcph->syn && !tcph->ack) {
        syn_packets++;
        detect_syn_flood(src_ip);
    }
    detect_port_scan(src_ip, dst_port);
    (void)src_port;
    (void)dst_ip;
}

/* summary */
static void print_summary(void) {
    printf("\n" COLOR_BLUE "========== NIDS-Lite Summary ==========\n" COLOR_RESET);
    printf("Total packets:      %lu\n", total_packets);
    printf("IPv4 packets:       %lu\n", ip_packets);
    printf("TCP packets:        %lu\n", tcp_packets);
    printf("UDP packets:        %lu\n", udp_packets);
    printf("ARP packets:        %lu\n", arp_packets);
    printf("DNS packets:        %lu\n", dns_packets);
    printf("Observed SYN pkts:  %lu\n", syn_packets);
    printf("Total alerts:       %lu\n", alerts_raised);
    printf(COLOR_BLUE "=======================================\n" COLOR_RESET);
}

int main(void) {
    int sockfd;
    unsigned char *buffer;
    struct sockaddr saddr;
    socklen_t saddr_len = sizeof(saddr);

    printf(COLOR_GREEN "NIDS-Lite starting... (Ctrl+C to stop)\n" COLOR_RESET);
    printf("Detection modules: SYN flood, Port scan, ARP spoof, DNS tunneling\n\n");

    signal(SIGINT, handle_sigint);

    init_syn_table();
    init_scan_table();
    init_arp_table();
    init_dns_table();

    buffer = (unsigned char *)malloc(65536);
    if (!buffer) {
        perror("malloc");
        exit(EXIT_FAILURE);
    }

    sockfd = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    if (sockfd < 0) {
        perror("socket(AF_PACKET)");
        free(buffer);
        exit(EXIT_FAILURE);
    }

    /* main receive loop: switched to for-style as requested */
    for (; keep_running; ) {
        ssize_t data_size = recvfrom(sockfd, buffer, 65536, 0, &saddr, &saddr_len);
        if (data_size < 0) {
            if (errno == EINTR) continue;
            perror("recvfrom");
            break;
        }

        total_packets++;

        if ((size_t)data_size < sizeof(struct ethhdr)) continue;

        struct ethhdr *eth = (struct ethhdr *)buffer;
        uint16_t ether_type = ntohs(eth->h_proto);

        switch (ether_type) {
            case ETH_P_IP: {
                ip_packets++;
                if ((size_t)data_size < sizeof(struct ethhdr) + sizeof(struct iphdr)) break;
                struct iphdr *iph = (struct iphdr *)(buffer + sizeof(struct ethhdr));
                if (iph->version != 4) break;
                switch (iph->protocol) {
                    case IPPROTO_TCP:
                        handle_tcp(buffer, (size_t)data_size);
                        break;
                    case IPPROTO_UDP:
                        handle_udp(buffer, (size_t)data_size);
                        break;
                    default:
                        break;
                }
            } break;

            case ETH_P_ARP:
                handle_arp(buffer, (size_t)data_size);
                break;

            default:
                break;
        }
    }

    close(sockfd);
    free(buffer);
    print_summary();
    return 0;
}
